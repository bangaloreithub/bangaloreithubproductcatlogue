# CCTV Website Template (Bangalore IT Hub)

## How to use this project:
1. Extract all files from this ZIP folder.
2. Put your logo image in the same folder and rename it to `logo.png`.
3. Open `index.html` in your text editor / GitHub editor and replace `919876543210` with your actual WhatsApp phone number.
4. Upload both `index.html` and `logo.png` to your GitHub Repository to publish your site via GitHub Pages.
